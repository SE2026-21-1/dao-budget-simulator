import os, sys, json, pathlib, subprocess, tempfile, socket, secrets, shutil, datetime
root='/tmp/dao-tv4-20261113'
output=pathlib.Path(sys.argv[1]); output.mkdir(mode=0o700)
bin='/tmp/tv4-pg18-20261113/node_modules/@embedded-postgres/linux-x64/native/bin'
env=dict(os.environ,PATH='/home/ptdung/.nvm/versions/node/v24.15.0/bin:'+os.environ['PATH'],LD_LIBRARY_PATH='/tmp/tv4-icu60-20261113/usr/lib/x86_64-linux-gnu')
owned=tempfile.mkdtemp(prefix='tv4-benchmark-owned-'); data=owned+'/data'
s=socket.socket(); s.bind(('127.0.0.1',0)); port=s.getsockname()[1]; s.close()
records=[]; password=secrets.token_hex(24)
def run(name,argv,extra=None,timeout=1200):
 e=dict(env); e.update(extra or {}); started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with open(output/(name+'.log'),'w') as log:
  p=subprocess.run(argv,cwd=root,env=e,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 records.append(dict(name=name,command=argv,exitCode=p.returncode,startedAt=started,completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 (output/'commands.json').write_text(json.dumps(records,indent=2))
 return p.returncode
started=False; result=1
try:
 (output/'source-sha.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True))
 assert run('initdb',[bin+'/initdb','-D',data,'-U','tv4_admin','--auth=trust','--encoding=UTF8','--locale=C'])==0
 pathlib.Path(data+'/postgresql.auto.conf').write_text(f"listen_addresses = '127.0.0.1'\nport = {port}\nunix_socket_directories = '{owned}'\n")
 assert run('postgres-start',[bin+'/pg_ctl','start','-w','-D',data,'-l',str(output/'postgres.log')])==0; started=True
 sql="const pg=require('./node_modules/pg'); (async()=>{const c=new pg.Client({host:'127.0.0.1',port:Number(process.env.OWN_PORT),user:'tv4_admin',database:'postgres'});await c.connect();await c.query(`CREATE ROLE be04_test LOGIN PASSWORD '${process.env.OWN_PASSWORD}'`);await c.query('CREATE DATABASE tv4_benchmark OWNER be04_test TEMPLATE template0');await c.end()})().catch(e=>{console.error(e.message);process.exitCode=1})"
 assert run('create-isolated-database',['node','-e',sql],{'OWN_PORT':str(port),'OWN_PASSWORD':password})==0
 result=run('benchmark',['node','--import','tsx','scripts/benchmark_api.mjs','--output',str(output/'benchmark.json')],{'TV4_BENCHMARK_ISOLATED':'1','TV4_BENCHMARK_DATABASE_URL':f'postgresql://be04_test:{password}@127.0.0.1:{port}/tv4_benchmark'})
finally:
 stopped=not started or run('postgres-stop',[bin+'/pg_ctl','stop','-w','-m','fast','-D',data])==0
 if stopped: shutil.rmtree(owned)
 (output/'driver-result.json').write_text(json.dumps({'exitCode':result,'clusterStopped':stopped,'ownedDirectoryRemoved':stopped,'port':port},indent=2))
print(json.dumps({'output':str(output),'exitCode':result,'stopped':stopped})); sys.exit(result)

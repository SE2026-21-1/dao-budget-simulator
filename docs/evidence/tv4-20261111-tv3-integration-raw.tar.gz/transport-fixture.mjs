import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
const root='/tmp/dao-tv4-qa05-20261111';
const { Interface,id,toQuantity }=createRequire(root+'/package.json')('ethers');
const manifest=JSON.parse(await readFile('/tmp/tv4-tv3-integration-20261111/manifest.json','utf8'));
const gov=new Interface(JSON.parse(await readFile(root+'/frontend/src/abi/BudgetGovernor.json','utf8')));
const treasury=new Interface(JSON.parse(await readFile(root+'/frontend/src/abi/Treasury.json','utf8')));
const bud=new Interface(['function balanceOf(address) view returns(uint256)']);
const a=manifest.accounts,c=Object.fromEntries(Object.entries(manifest.contracts).map(([k,v])=>[k,v.address]));
let seq=0;
async function rpc(method,params=[]){const b=await(await fetch('http://127.0.0.1:18641',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:++seq,method,params})})).json();if(b.error)throw Error(JSON.stringify(b.error));return b.result;}
async function call(method,args=[]){return gov.decodeFunctionResult(method,await rpc('eth_call',[{to:c.Governor,data:gov.encodeFunctionData(method,args)},'latest']))[0];}
const receipts=[];
async function tx(from,method,args,at){if(at)await rpc('evm_setNextBlockTimestamp',[Number(at)]);const h=await rpc('eth_sendTransaction',[{from,to:c.Governor,data:gov.encodeFunctionData(method,args),gas:toQuantity(8000000)}]);let r;for(let i=0;i<100;i++){r=await rpc('eth_getTransactionReceipt',[h]);if(r)break;await new Promise(done=>setTimeout(done,25));}if(!r||r.status!=='0x1')throw Error('setup revert '+method);receipts.push(r);return h;}
const description=JSON.stringify({version:1,title:'TV4 snapshot signing guard',body:'Disposable HTTP transport fixture over real isolated Anvil governance. Not production API or extension acceptance.'});
const requestId=id('tv4:browser-snapshot-guard:'+Date.now());
const action=[[c.Treasury],[0],[treasury.encodeFunctionData('disburse',[requestId,a.recipient,1000n*10n**18n])],id(description)];
const pid=await call('hashProposal',action);
const created=await tx(a.A,'propose',[...action.slice(0,3),description]);
const snapshot=await call('proposalSnapshot',[pid]),deadline=await call('proposalDeadline',[pid]);
await tx(a.A,'castVote',[pid,1],snapshot+1n);await tx(a.B,'castVote',[pid,1],snapshot+1n);
const queued=await tx(a.caller,'queue',action,deadline+1n);const eta=await call('proposalEta',[pid]);await rpc('evm_setNextBlockTimestamp',[Number(eta)]);await rpc('evm_mine');
let mode='ok',revision='1';
async function context(){const h=await rpc('eth_getBlockByNumber',['latest',false]);return {chainId:'31337',deploymentId:'tv3-outcome-ui',dataKind:'chain',asOfBlock:BigInt(h.number).toString(),asOfBlockHash:h.hash,asOfTimestamp:BigInt(h.timestamp).toString(),snapshotRevision:revision,sync:{status:'synced',lagSeconds:'0',lagBlocks:'0'}};}
async function proposal(){const status=Number(await call('state',[pid]));return {proposalId:String(pid),requestId,proposer:a.A,recipient:a.recipient,amount:String(1000n*10n**18n),description,title:'TV4 snapshot signing guard',body:'Disposable API transport fixture; real Anvil receipt. Not extension or backend acceptance.',descriptionHash:action[3],targets:action[0],values:['0'],calldatas:action[2],snapshot:String(snapshot),deadline:String(deadline),state:['Pending','Active','Canceled','Defeated','Succeeded','Queued','Expired','Executed'][status],votes:{against:'0',for:String(700n*10n**18n),abstain:'0',quorum:String(200n*10n**18n)},operation:{eta:String(eta),status:status===7?'Done':'Ready'},transactions:{created,queued,executed:null,canceled:null}};}
const server=createServer(async(req,res)=>{try{const u=new URL(req.url,'http://localhost');res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('content-type','application/json');if(req.method==='OPTIONS'){res.statusCode=204;res.end();return;}if(u.pathname==='/control'){mode=u.searchParams.get('mode')??'ok';revision=u.searchParams.get('revision')??revision;res.end(JSON.stringify({mode,revision}));return;}
const ctx=await context();if(u.pathname==='/api/health'){res.end(JSON.stringify({context:ctx,data:{status:'ok',database:'ok',indexer:'synced',publication:'ready'}}));return;}
if(mode!=='ok'){res.statusCode=Number(mode);res.end(JSON.stringify({error:{code:mode==='409'?'SNAPSHOT_INVALIDATED':'DATA_NOT_READY',message:'Controlled snapshot recovery fixture'}}));return;}
if(u.pathname==='/api/proposals'){res.end(JSON.stringify({context:ctx,data:[await proposal()],pagination:{totalCount:1,nextCursor:null}}));return;}
if(u.pathname==='/api/summary'){const balance=bud.decodeFunctionResult('balanceOf',await rpc('eth_call',[{to:c.BUD,data:bud.encodeFunctionData('balanceOf',[c.Treasury])},'latest']))[0];res.end(JSON.stringify({context:ctx,data:{treasury:{address:c.Treasury,token:{address:c.BUD},balance:String(balance),totalIn:String(10000n*10n**18n),totalOut:String(10000n*10n**18n-balance)},proposalCounts:{total:1,byState:{}},governance:{governor:c.Governor,timelock:c.Timelock,govToken:{address:c.GOV},proposalThreshold:String(50n*10n**18n)},recentActivity:[]}}));return;}
if(u.pathname==='/api/treasury/transfers'){res.end(JSON.stringify({context:ctx,data:[],pagination:{totalCount:0,nextCursor:null}}));return;}
res.statusCode=404;res.end(JSON.stringify({error:{code:'NOT_FOUND'}}));}catch(e){res.statusCode=500;res.end(JSON.stringify({error:{code:'HARNESS_ERROR',message:e.message}}));}});
await writeFile('/tmp/tv4-tv3-integration-20261111/setup.json',JSON.stringify({scope:'Controlled HTTP API transport fixture over real owned Anvil; not live PostgreSQL/worker/extension acceptance',proposalId:String(pid),created,queued,receipts,context:await context(),contracts:c,accounts:a},null,2));
server.listen(18642,'127.0.0.1',()=>console.log('SNAPSHOT_FIXTURE_READY'));

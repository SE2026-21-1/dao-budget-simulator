# BE06 compare tại H=67

Kết quả: **PASS — dữ liệu chuẩn hóa bằng nhau.**

- Hash tham chiếu: 0xb41227e63125e21db9d061f42539759f8b714ce58a10e6cf23d4ea6965618ac0
- Hash rebuild: 0xb41227e63125e21db9d061f42539759f8b714ce58a10e6cf23d4ea6965618ac0
- Scope khớp: yes
- Chain cross-check: PASS (state, proposalVotes/quorum, timelock, clock/linkage, balanceOf)
- Proposals: 6 / 6
- Votes: 9 / 9
- Operations: 3 / 3
- Transfers: 4 / 4
- Disbursements: 2 / 2
- Treasury in/out/balance: 13000000000000000000000 / 12000000000000000000000 / 1000000000000000000000
- Decode warnings retained: 16 / 16

## Mismatches

None.

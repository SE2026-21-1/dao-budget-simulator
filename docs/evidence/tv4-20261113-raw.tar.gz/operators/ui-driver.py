import os,sys,json,pathlib,subprocess,tempfile,socket,signal,time,shutil
root=sys.argv[1];out=pathlib.Path(sys.argv[2]);out.mkdir(mode=0o700)
bin='/tmp/tv4-pg18-20261113/node_modules/@embedded-postgres/linux-x64/native/bin';owned=tempfile.mkdtemp(prefix='tv4-ui-owned-');data=owned+'/data'
env=dict(os.environ,PATH='/home/ptdung/.nvm/versions/node/v24.15.0/bin:'+os.environ['PATH'],LD_LIBRARY_PATH='/tmp/tv4-icu60-20261113/usr/lib/x86_64-linux-gnu')
def port():
 s=socket.socket();s.bind(('127.0.0.1',0));p=s.getsockname()[1];s.close();return p
pgport=port();rpcport=port();children=[];logs=[];records=[];stopped=False
signal.signal(signal.SIGTERM,lambda *_:globals().update(stopped=True));signal.signal(signal.SIGINT,lambda *_:globals().update(stopped=True))
def run(name,args,extra=None):
 e=dict(env);e.update(extra or {});f=open(out/(name+'.log'),'w');logs.append(f);p=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT);records.append({'name':name,'command':args,'exitCode':p.returncode});assert p.returncode==0,name

def start(name,args,extra=None):
 e=dict(env);e.update(extra or {});f=open(out/(name+'.log'),'w');logs.append(f);p=subprocess.Popen(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);children.append((name,p));return p

def waitport(p,child=None):
 for _ in range(600):
  if child and child.poll() is not None:raise RuntimeError('owned child exited before ready')
  try:
   with socket.create_connection(('127.0.0.1',p),timeout=.2):return
  except OSError:time.sleep(.1)
 raise RuntimeError('port readiness timed out')
try:
 (out/'source-sha.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True))
 run('initdb',[bin+'/initdb','-D',data,'-U','tv4_ui_admin','--auth=trust','--encoding=UTF8','--locale=C'])
 pathlib.Path(data+'/postgresql.auto.conf').write_text(f"listen_addresses = '127.0.0.1'\nport = {pgport}\nunix_socket_directories = '{owned}'\n")
 run('postgres-start',[bin+'/pg_ctl','start','-w','-D',data,'-l',str(out/'postgres.log')])
 run('database-create',['node','-e',"const pg=require('./node_modules/pg');(async()=>{const c=new pg.Client({host:'127.0.0.1',port:Number(process.env.OWN_PORT),user:'tv4_ui_admin',database:'postgres'});await c.connect();await c.query('CREATE ROLE ui_owner LOGIN');await c.query('CREATE DATABASE tv4_ui OWNER ui_owner TEMPLATE template0');await c.end()})().catch(e=>{console.error(e);process.exitCode=1})"],{'OWN_PORT':str(pgport)})
 anvil=start('anvil',['anvil','--host','127.0.0.1','--port',str(rpcport),'--chain-id','31337','--hardfork','osaka','--silent']);waitport(rpcport,anvil)
 rpc='http://127.0.0.1:'+str(rpcport)
 run('deploy',['node','scripts/deploy_local.mjs','--rpc',rpc,'--output',str(out/'manifest.json')])
 boot=start('bootstrap',['node','--import','tsx','/tmp/tv4-ui-bootstrap.mjs',root,str(out),rpc],{'UI_ADMIN_URL':f'postgresql://tv4_ui_admin@127.0.0.1:{pgport}/postgres','UI_DATABASE_URL':f'postgresql://ui_owner@127.0.0.1:{pgport}/tv4_ui'})
 for _ in range(1200):
  if boot.poll() is not None:raise RuntimeError('bootstrap exited')
  if (out/'ui-ready.json').exists():break
  time.sleep(.1)
 cfg=json.loads((out/'ui-ready.json').read_text());a=cfg['addresses']
 ve={'VITE_API_BASE_URL':cfg['apiBase'],'VITE_DATA_SOURCE':'api','VITE_CHAIN_ID':'31337','VITE_RPC_URL':rpc,'VITE_DEPLOYMENT_ID':cfg['deploymentId'],'VITE_GOVERNOR_ADDRESS':a['Governor'],'VITE_TREASURY_ADDRESS':a['Treasury'],'VITE_GOV_TOKEN_ADDRESS':a['GOV'],'VITE_BUD_TOKEN_ADDRESS':a['BUD'],'VITE_TIMELOCK_ADDRESS':a['Timelock']}
 vite=start('vite',['npm','run','dev','--prefix','frontend','--','--host','127.0.0.1','--port','5173','--strictPort'],ve);waitport(5173,vite)
 (out/'frontend-public-config.json').write_text(json.dumps(ve,indent=2));print('TV4_UI_READY '+str(out/'ui-ready.json'),flush=True)
 while not stopped:
  if any(p.poll() is not None for _,p in children):raise RuntimeError('owned service exited unexpectedly')
  time.sleep(.5)
finally:
 for name,p in reversed(children):
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  records.append({'name':name,'pid':p.pid,'exitCode':p.returncode})
 p=subprocess.run([bin+'/pg_ctl','stop','-w','-m','fast','-D',data],env=env,capture_output=True,text=True);(out/'postgres-stop.log').write_text(p.stdout+p.stderr)
 records.append({'name':'postgres-stop','exitCode':p.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2))
 if p.returncode==0:shutil.rmtree(owned)
 for f in logs:f.close()
 print('TV4_UI_STOPPED',flush=True)

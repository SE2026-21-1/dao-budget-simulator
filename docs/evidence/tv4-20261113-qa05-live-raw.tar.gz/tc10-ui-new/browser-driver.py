# Executed by Eval with the live browser bridge and qa05out/control/tab globals.
# Native keyboard events only; never writes React/app state or DOM form values.
import json, urllib.request

async def qa05_observe_checkpoint(c):
    route='/proposals/'+c['proposals'][0]['id'] if c['proposals'] else '/'
    await qa05tab.clearConsole(); await qa05tab.clearRequests()
    await qa05tab.goto('http://127.0.0.1:5174'+route,wait_until='domcontentloaded',timeout=60)
    actor=c.get('ui',{}).get('account',c['accounts']['A'])
    await qa05tab.evaluate('window.__tv4SwitchAccount('+json.dumps(actor)+')')
    if c['proposals']: await qa05tab.waitForSelector('.detail-title .status-pill',timeout=30000)
    else: await qa05tab.waitForSelector('.snapshot-info',timeout=30000)
    expected={'hash':c['context']['asOfBlockHash'],'revision':c['context']['snapshotRevision'],'account':actor}
    js='''const expected=JSON.parse(EXPECTED); await page.waitForFunction((a)=>{const s=document.querySelector('.snapshot-info');const w=document.querySelector('.header-wallet');return s&&s.textContent.includes(a.hash)&&s.textContent.includes(a.revision)&&w&&w.textContent.toLowerCase().includes(a.account.slice(0,6).toLowerCase())&&w.textContent.toLowerCase().includes(a.account.slice(-4).toLowerCase());},{timeout:30000},expected);return await page.evaluate(()=>({body:document.body.innerText,snapshot:document.querySelector('.snapshot-info').innerText,status:document.querySelector('.detail-title .status-pill')?.textContent,overflow:document.documentElement.scrollWidth>innerWidth,buttons:Array.from(document.querySelectorAll('.proposal-actions button')).map(b=>({text:b.textContent,disabled:b.disabled})),wallet:document.querySelector('.header-wallet').textContent,actions:document.querySelector('.proposal-actions')?.innerText,walletLog:window.__tv4WalletLog}));'''
    seen=await qa05tab.run(js.replace('EXPECTED',json.dumps(json.dumps(expected))),timeout=45)
    seen['walletLog']=await qa05tab.evaluate('window.__tv4WalletLog')
    assert not seen['overflow'],('overflow',c['case'],c['stage'])
    assert 'Fixture BE01' not in seen['body'] and 'API' in seen['snapshot']
    assert not [r for r in seen['walletLog'] if r['method']=='eth_sendTransaction']
    if c['proposals']:
        state=c['expectedStates'][0]; assert seen['status']==state,(seen['status'],state)
        assert c['proposals'][0]['id'] in seen['body']
        description=json.loads(c['proposals'][0]['description']); assert description['body'] in seen['body']
        buttons={b['text']:b['disabled'] for b in seen['buttons']}
        if state=='Pending': assert buttons.get('Hủy đề xuất') is (not c['ui'].get('cancelEnabled',False)),buttons
        elif state=='Succeeded': assert buttons.get('Queue') is False,buttons
        elif state=='Queued': assert buttons.get('Execute') is (c['ui'].get('expectedOperation')!='Ready'),buttons
        else: assert 'Hủy đề xuất' not in buttons,buttons
        if state in ('Canceled','Executed','Defeated'): assert not buttons,buttons
        if state=='Canceled': assert 'Failed' not in seen['body'] and 'Canceled' in seen['body']
    errors=await qa05tab.errors(); console=await qa05tab.console(); network=await qa05tab.requests()
    assert not [e for e in errors.get('entries',[]) if e.get('type') in ('pageerror','exception')],errors
    result={'id':c['id'],'status':'PASS','case':c['case'],'stage':c['stage'],'url':'http://127.0.0.1:5174'+route,'actor':actor,'viewport':1366,'observed':seen,'errors':errors,'console':console,'network':network,'forms':[],'scope':'Actual integrated browser with owned unlocked Anvil adapter and real live API, not extension/testnet. Read/action-eligibility proof; no UI transaction broadcast in this checkpoint.'}
    if c.get('ui',{}).get('tc10'): result['tc10']=await qa05_tc10_browser(c)
    if c.get('ui',{}).get('tc10'):
        result['errors']=await qa05tab.errors(); result['network']=await qa05tab.requests(); result['console']=await qa05tab.console()
        assert not [e for e in result['errors'].get('entries',[]) if e.get('type') in ('pageerror','exception')],result['errors']
    for vector in c.get('uiForms',[]):
        await qa05tab.goto('http://127.0.0.1:5174/proposals/new',wait_until='domcontentloaded',timeout=60)
        await qa05tab.waitForSelector('#proposal-title',timeout=30000)
        for name in ('title','body','recipient','amount'):
            selector='#proposal-'+name; value=vector['input'][name]
            await qa05tab.run('await page.focus('+json.dumps(selector)+');await page.keyboard.down("Control");await page.keyboard.press("KeyA");await page.keyboard.up("Control");await page.keyboard.sendCharacter('+json.dumps(value)+');return true;')
            assert await qa05tab.value(selector)==value
        enabled=await qa05tab.isEnabled('role/button[name="Tiếp tục: xem lại"]'); assert enabled==vector['expected']['valid'],(vector['label'],enabled)
        observed={'label':vector['label'],'input':vector['input'],'expected':vector['expected'],'reviewEnabled':enabled,'inputMethod':'native keyboard.sendCharacter (CDP Input.insertText), exact field values observed'}
        if enabled:
            await qa05tab.click('role/button[name="Tiếp tục: xem lại"]'); await qa05tab.waitForSelector('.proposal-review')
            await qa05tab.run("await page.waitForFunction(()=>document.querySelector('button[type=submit]')?.disabled===false,{timeout:30000});return true;")
            preview=await qa05tab.run("return await page.evaluate(()=>({title:document.querySelector('.proposal-review strong').textContent,body:document.querySelector('.proposal-review p:nth-of-type(2)').textContent,sendDisabled:document.querySelector('button[type=submit]').disabled}));")
            assert preview['title']==vector['input']['title']; assert preview['body']=='Mô tả: '+vector['input']['body']; assert preview['sendDisabled'] is False,preview; observed['preview']=preview
        else: assert vector['expected']['error'] in await qa05tab.text(),vector['label']
        observed['errors']=await qa05tab.errors(); observed['network']=await qa05tab.requests()
        assert not [e for e in observed['errors'].get('entries',[]) if e.get('type') in ('pageerror','exception')],observed['errors']
        result['forms'].append(observed)
    (qa05out/f'browser-{c["id"]}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return result

async def qa05_drive_all():
    count=0; failures=[]
    with urllib.request.urlopen(qa05control+'/events',timeout=3600) as events:
        for rawline in events:
            line=rawline.decode().strip()
            if line.startswith('event: done'): break
            if not line.startswith('data: '): continue
            c=json.loads(line[6:])
            if not c.get('id'): continue
            try: result=await qa05_observe_checkpoint(c)
            except Exception as e:
                result={'id':c['id'],'status':'FAIL','case':c['case'],'stage':c['stage'],'error':repr(e),'errors':await qa05tab.errors(),'console':await qa05tab.console(),'network':await qa05tab.requests(),'body':await qa05tab.text()}
                (qa05out/f'browser-{c["id"]}-failure.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n'); failures.append(result)
            request=urllib.request.Request(qa05control+'/ack',data=json.dumps(result).encode(),headers={'Content-Type':'application/json'},method='POST')
            with urllib.request.urlopen(request,timeout=30) as response: assert response.status==200
            count+=1
            if count%25==0 or result['status']!='PASS': print('Actual UI checkpoints',count,c['case'],c['stage'],result['status'],flush=True)
            if failures: break
    return {'checkpoints':count,'failures':failures}

async def qa05_tc10_browser(c):
    proof=c['ui']['tc10']; details=[]
    for index,p in enumerate(c['proposals']):
        await qa05tab.goto('http://127.0.0.1:5174/proposals/'+p['id'],wait_until='domcontentloaded',timeout=60)
        await qa05tab.evaluate('window.__tv4SwitchAccount('+json.dumps(c['ui']['account'])+')')
        await qa05tab.waitForSelector('.detail-title .status-pill',timeout=30000)
        state=await qa05tab.text('.detail-title .status-pill'); assert state==c['expectedStates'][index]
        body=await qa05tab.text(); snapshot=await qa05tab.text('.snapshot-info')
        assert c['context']['asOfBlockHash'] in snapshot and c['context']['snapshotRevision'] in snapshot
        winner=p['id']==proof['winnerId']
        assert ('Đã đối chiếu 2 phiếu và '+('1' if winner else '0')+' Transfer') in body
        if winner: assert proof['winnerTransaction'] in body
        if not winner:
            assert proof['winnerTransaction'] not in body
            await qa05tab.run("await page.waitForFunction(()=>Array.from(document.querySelectorAll('.proposal-actions button')).some(b=>b.textContent==='Execute'&&!b.disabled),{timeout:30000});return true;")
            await qa05tab.click('role/button[name="Execute"]')
            await qa05tab.run("await page.waitForFunction(()=>document.body.innerText.includes('Request ID đã được Treasury thanh toán.'),{timeout:30000});return true;")
            body=await qa05tab.text()
        walletlog=await qa05tab.evaluate('window.__tv4WalletLog')
        assert not [r for r in walletlog if r['method']=='eth_sendTransaction']
        details.append({'proposalId':p['id'],'state':state,'winner':winner,'snapshot':snapshot,'body':body,'walletLog':walletlog})
    await qa05tab.goto('http://127.0.0.1:5174/treasury',wait_until='domcontentloaded',timeout=60)
    await qa05tab.waitForSelector('.treasury-history__list',timeout=30000)
    treasury=await qa05tab.run("return await page.evaluate(()=>({snapshot:document.querySelector('.snapshot-info').textContent,stats:Array.from(document.querySelectorAll('.treasury-stats strong')).map(x=>x.title),rows:Array.from(document.querySelectorAll('.treasury-history__list>div')).map(r=>({direction:r.querySelector('span').textContent,amount:r.querySelector('strong').textContent,hash:r.querySelector('code[title],a[title]').title})),overflow:document.documentElement.scrollWidth>innerWidth}));")
    assert c['context']['asOfBlockHash'] in treasury['snapshot'] and c['context']['snapshotRevision'] in treasury['snapshot']
    out=[r for r in treasury['rows'] if r['direction']=='Chi']; assert len(out)==1
    assert out[0]['hash']==proof['winnerTransaction']; amount=int(proof['amount'])//10**18
    digits=lambda text:int(''.join(ch for ch in text if ch.isdigit()))
    assert digits(out[0]['amount'])==amount
    assert [digits(v) for v in treasury['stats']]==[10000-amount,10000,amount]
    assert not treasury['overflow']
    return {'details':details,'treasury':treasury,'duplicateUiPreflight':'Request ID đã được Treasury thanh toán.; zero wallet sends','sameSnapshot':True}
